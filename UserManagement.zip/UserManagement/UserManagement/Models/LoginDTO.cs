using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.Models
{
    public class LoginDTO
    {
        public string userName { get; set; }
        public string passWord { get; set; }
    }
}